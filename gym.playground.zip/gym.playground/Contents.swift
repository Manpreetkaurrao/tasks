//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
enum Choice
{   case strength
    case yoga
    case crossfit
    case aerobic
}
/*Main super class Gym*/
class Gym
{
    var equipment_strength : [String]
    var euipment_yoga : [String]
    var equipment_crossfit : [String]
    var equipment_aerobic : [String]
    init()
    {
        equipment_strength = ["barbell", "dumbbells", "weight plates", "EZcurl bar", "benches" ]
        euipment_yoga = ["yoga mat", "blanket", "blocks", "straps"]
        equipment_crossfit = ["medicine ball", "squat box", "kettlebells", "slam ball"]
        equipment_aerobic = ["bodyrev", "step", "toning bar", "stability balls"]
    }
    func workout_schedule()
    {}
    func enrollment_process()
    {}
    func diet_plan()
    {}
}

/*Strength_gym class inheriting Super Class Gym*/
class Strength_gym : Gym
{
    override func workout_schedule()
    {
        print("equipmet to be used for Strength_gym are :")
        print("\(equipment_strength)")
        print("workout schedule for strength gym:\nEach equipment will be used \n In starting there will be 10-10 round for each after")
    }
    override func enrollment_process()
    {
        print("enrollment process for strength gym\nAge must be greater than 18 and less than 60\nCharges are 1000 per head for normal training and 5000 per head for special training")
    }
    override func diet_plan()
    {
        print("diet plan for strength gym\ndiet chart: \nMilk : 1 ltr\nEggs : 12/day\nWheat : 8 Chapatti/day")
    }
}

/*Yoga_gym class inheriting Super Class Gym*/
class Yoga_gym : Gym
{
    override func workout_schedule()
    {
        print("equipmet to be used for Yoga_gym are :")
        print("\(euipment_yoga)")
        print("workout schedule for Yoga_gym\nyoga classes will be there in the morning and evening foe 2-2 hours")
    }
    override func enrollment_process()
    {
        print("enrollment process for Yoga_gym")
        print("Person of any age can join yoga classes")
    }
    override func diet_plan()
    {
        print("diet plan for Yoga_gym")
        print("Say no to junk food \nDrink lots of water\nDo meditation\nOther Yoga will be done at gym")
    }
}

/*Crossfit_gym class inheriting Super Class Gym*/
class Crossfit_gym : Gym
{
    override func workout_schedule()
    {
        print("equipmet to be used for Crossfit_gym are :")
        print("\(euipment_yoga)")
        print("\(equipment_crossfit)")
        print("workout schedule for Crossfit_gym\nThis will be held post lunch")
    }
    override func enrollment_process()
    {
        print("enrollment process for Crossfit_gym\nAny age group can apply for crossfit gym except kids and old ")
    }
    override func diet_plan()
    {
        print("diet plan for Crossfit_gym\nEat Salaad a lot\nSay no to rice\nDrink a lot of water")
    }
}

/*Aerobic_gym class inheriting Super Class Gym*/
class Aerobic_gym : Gym
{
    override func workout_schedule()
    {
        print("equipmet to be used for Aerobic_gym are :")
        print("\(euipment_yoga)")
        print("\(equipment_aerobic)")
        print("workout schedule for Aerobic_gym")
    }
    override func enrollment_process()
    {
        print("enrollment process for Aerobic_gym")
    }
    override func diet_plan()
    {
        print("diet plan for Aerobic_gym")
    }
}

/*Make choice for the gym you want to join*/
var gym_to_join = Choice.strength
switch gym_to_join
{
    case .strength:
                    let S_gym = Strength_gym()
                    S_gym.workout_schedule()
                    S_gym.enrollment_process()
                    S_gym.diet_plan()
    case .yoga:
                    let Y_gym = Yoga_gym()
                    Y_gym.workout_schedule()
                    Y_gym.enrollment_process()
                    Y_gym.diet_plan()
    case .crossfit:
                    let C_gym = Crossfit_gym()
                    C_gym.workout_schedule()
                    C_gym.enrollment_process()
                    C_gym.diet_plan()
    case .aerobic:
                    let A_gym = Aerobic_gym()
                    A_gym.workout_schedule()
                    A_gym.enrollment_process()
                    A_gym.diet_plan()
}
