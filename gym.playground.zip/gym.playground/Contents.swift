//: Playground - noun: a place where people can play

import UIKit

enum Choice
{   case strength
    case yoga
    case crossfit
    case aerobic
}
class Gym_equipment
{
    func dumbells(){}
    func yoga_mat(){}
    func slam_ball(){}
    func weight_plats(){}
    func bodyrev(){}
    func stepper(){}
    func benches(){}
    func medicine_ball(){}
    func squat_rack(){}
    func legpress_machine(){}

}

/*Main super class Gym*/
protocol Gym
{
    func workout_schedule()
    func enrollment_process()
    func diet_plan()
}

/*Strength_gym class inheriting Super Class Gym*/
class Strength_gym : Gym_equipment, Gym
{
    func workout_schedule()
    {
        print("equipmet to be used for Strength_gym are :")
        
        print("workout schedule for strength gym:\nEach equipment will be used \n In starting there will be 10-10 round for each after")
    }
    func enrollment_process()
    {
        print("enrollment process for strength gym\nAge must be greater than 18 and less than 60\nCharges are 1000 per head for normal training and 5000 per head for special training")
    }
    func diet_plan()
    {
        print("diet plan for strength gym\ndiet chart: \nMilk : 1 ltr\nEggs : 12/day\nWheat : 8 Chapatti/day")
    }
    override func dumbells()
    {
        print("Working of Dumbbells")
    }
    override func weight_plats()
    {
    print("Working of weight plates")
    }
    override func legpress_machine()
    {
        print("Working of legpress_machine")
    }
    
}

/*Yoga_gym class inheriting Super Class Gym*/
class Yoga_gym : Gym_equipment, Gym
{
    func workout_schedule()
    {
        print("equipmet to be used for Yoga_gym are :")
        print("workout schedule for Yoga_gym\nyoga classes will be there in the morning and evening foe 2-2 hours")
    }
    func enrollment_process()
    {
        print("enrollment process for Yoga_gym")
        print("Person of any age can join yoga classes")
    }
    func diet_plan()
    {
        print("diet plan for Yoga_gym")
        print("Say no to junk food \nDrink lots of water\nDo meditation\nOther Yoga will be done at gym")
    }
    override func yoga_mat()
    {
        print("yoga mat exercises")
    }
}

/*Crossfit_gym class inheriting Super Class Gym*/
class Crossfit_gym : Gym_equipment, Gym
{
    func workout_schedule()
    {
        print("equipmet to be used for Crossfit_gym are :")
        print("workout schedule for Crossfit_gym\nThis will be held post lunch")
    }
    func enrollment_process()
    {
        print("enrollment process for Crossfit_gym\nAny age group can apply for crossfit gym except kids and old ")
    }
    func diet_plan()
    {
        print("diet plan for Crossfit_gym\nEat Salaad a lot\nSay no to rice\nDrink a lot of water")
    }
    override func slam_ball()
    {
        print("exercises with slam ball")
    }
    override func stepper()
    {
        print("exercises with stepper")

    }
    override func benches()
    {
        print("exercises with benches")
    }
    override func bodyrev()
    {
        print("exercises with bodyrev")
    }
    
}

/*Aerobic_gym class inheriting Super Class Gym*/
class Aerobic_gym : Gym_equipment, Gym
{
    func workout_schedule()
    {
        print("equipmet to be used for Aerobic_gym are :")
        print("workout schedule for Aerobic_gym")
    }
    func enrollment_process()
    {
        print("enrollment process for Aerobic_gym")
    }
    func diet_plan()
    {
        print("diet plan for Aerobic_gym")
    }
    override func medicine_ball()
    {
        print("diet plan for Medicine_ball")
    }
    override func squat_rack()
    {
        print("diet plan for Squat rack")
    }
    override func legpress_machine()
    {
        print("diet plan for Leg press Machine")
    }
    override func yoga_mat()
    {
        print("yoga mat exercises")
    }
}

/*Make choice for the gym you want to join*/
var gym_to_join = Choice.strength
switch gym_to_join
{
    case .strength:
                    let Sgym_obj = Strength_gym()
                    Sgym_obj.workout_schedule()
                    Sgym_obj.enrollment_process()
                    Sgym_obj.diet_plan()
                    Sgym_obj.dumbells()
                    Sgym_obj.weight_plats()
                    Sgym_obj.legpress_machine()
    case .yoga:
                    let Ygym_obj = Yoga_gym()
                    Ygym_obj.workout_schedule()
                    Ygym_obj.enrollment_process()
                    Ygym_obj.diet_plan()
                    Ygym_obj.yoga_mat()
    case .crossfit:
                    let Cgym_obj = Crossfit_gym()
                    Cgym_obj.workout_schedule()
                    Cgym_obj.enrollment_process()
                    Cgym_obj.diet_plan()
                    Cgym_obj.slam_ball()
                    Cgym_obj.stepper()
                    Cgym_obj.benches()
                    Cgym_obj.bodyrev()
    case .aerobic:
                    let Agym_obj = Aerobic_gym()
                    Agym_obj.workout_schedule()
                    Agym_obj.enrollment_process()
                    Agym_obj.diet_plan()
                    Agym_obj.medicine_ball()
                    Agym_obj.squat_rack()
                    Agym_obj.legpress_machine()
                    Agym_obj.yoga_mat()
}
