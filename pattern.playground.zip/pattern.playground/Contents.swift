//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
for i in 0..<5
{
    for j in 0...i
    {
        print("*",terminator : "")
    }
    print("")
}