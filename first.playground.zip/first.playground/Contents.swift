//: Playground - noun: a place where people can play

import UIKit
for i in 0...10
{
    print(i)
}
var str = "Hello, playground"
print(str)
